import React, { useState } from 'react'
import { motion } from 'framer-motion'

export default function App() {
  const [messages, setMessages] = useState([
    { from: 'ai', text: 'Hi love 💕 I’m your romantic AI companion. How was your day?' }
  ])
  const [input, setInput] = useState('')

  const sendMessage = () => {
    if (!input.trim()) return
    setMessages([...messages, { from: 'user', text: input }, { from: 'ai', text: 'That sounds so sweet 😘' }])
    setInput('')
  }

  return (
    <div style={{minHeight:'100vh', background:'#fde2e4'}} className="flex flex-col items-center justify-center p-6">
      <motion.div
        style={{background:'white', borderRadius:'16px', boxShadow:'0 4px 12px rgba(0,0,0,0.1)'}}
        className="w-full max-w-md p-4 flex flex-col"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 style={{color:'#ec4899'}} className="text-2xl font-bold mb-4 text-center">💖 Romantic AI 💖</h1>
        <div className="flex-1 overflow-y-auto space-y-2 mb-4">
          {messages.map((m, i) => (
            <div key={i} style={{textAlign: m.from === 'ai' ? 'left' : 'right', color: m.from === 'ai' ? '#ec4899' : '#374151'}}>
              <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }}>{m.text}</motion.p>
            </div>
          ))}
        </div>
        <div className="flex space-x-2">
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            placeholder="Write something romantic..."
            style={{flex:1, border:'1px solid #f472b6', borderRadius:'12px', padding:'8px'}}
          />
          <button
            onClick={sendMessage}
            style={{background:'#ec4899', color:'white', padding:'8px 16px', borderRadius:'12px'}}
          >
            Send
          </button>
        </div>
      </motion.div>
    </div>
  )
}
